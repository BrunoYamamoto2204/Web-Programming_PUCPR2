document.getElementById("nome").innerHTML = localStorage.getItem("resposta-nome")
document.getElementById("email").innerHTML = localStorage.getItem("resposta-email")
document.getElementById("celular").innerHTML = localStorage.getItem("resposta-celular")
document.getElementById("nascimento").innerHTML= localStorage.getItem("resposta-nascimento")